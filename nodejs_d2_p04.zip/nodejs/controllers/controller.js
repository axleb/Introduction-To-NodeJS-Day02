const Employee = require('../models/employee');
exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
//
exports.aboutus=function(req, res){
  res.send('You are on the about us route.');
};
//
exports.getemployees=function(req, res){
  //res.send('You are on the getdocs route.');
  Employee.find({})
  .then(
    employeeData => res.send(employeeData)
  )
  .catch((err)=>{
    res.send(err);
  });
};
//
exports.getemployee = function(req, res) {
  let empToFind = req.params.employeeName;
  Employee.find({empName:empToFind})
  .then(
    employeeData => {
      if(employeeData.length === 0)
        //res.send("No data!");
        res.send({"message":"No Data!"});
      else
        res.send(employeeData);
    }
  )
  .catch((err)=>{
    res.send(err);
  });
};
//
exports.addemployee = function(req, res){ 
  let empName = req.body.empName;
  let empPass = req.body.empPass;
  const Emp = new Employee();
  Emp.empName = empName;
	Emp.empPass = empPass;
  Emp.save()
  .then(msg => {
    res.send({"message":"Created " + Emp.empName});
  })
  .catch(
    err => res.send({"message":err.message})
  );
};
