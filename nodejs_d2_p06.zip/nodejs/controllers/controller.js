const jwt = require('jsonwebtoken');
const Employee = require('../models/employee');
exports.getdefault = function(req, res){
  res.send('You are on the root route.');
};
//
exports.aboutus=function(req, res){
  res.send('You are on the about us route.');
};
//
exports.getemployees=function(req, res){
  //res.send('You are on the getdocs route.');
  Employee.find({})
  .then(
    employeeData => res.send(employeeData)
  )
  .catch((err)=>{
    res.send(err);
  });
};
//
exports.getemployee = function(req, res) {
  let empToFind = req.params.employeeName;
  Employee.find({empName:empToFind})
  .then(
    employeeData => {
      if(employeeData.length === 0)
        //res.send("No data!");
        res.send({"message":"No Data!"});
      else
        res.send(employeeData);
    }
  )
  .catch((err)=>{
    res.send(err);
  });
};
//
exports.addemployee = function(req, res){ 
  let empName = req.body.empName;
  let empPass = req.body.empPass;
  const Emp = new Employee();
  Emp.empName = empName;
	Emp.empPass = empPass;
  Emp.save()
  .then(msg => {
    res.send({"message":"Created " + Emp.empName});
  })
  .catch(
    err => res.send({"message":err.message})
  );
};
//
exports.loginuser=function(req, res){
  let empName = req.body.empName;
  let empPass = req.body.empPass;
  Employee.find({ empName: empName })
    .then(
      employeeData => {
        if (employeeData.length === 0)
          res.send({ "message": empName + " not found!" });
        else {
          if (employeeData[0].empPass == empPass) {
            var token = jwt.sign(
              {
                empName: employeeData[0].empname,
                userID: employeeData[0]._id
              },
              "shhhh",
              { expiresIn: "1h" },
              (err, token) => {
                if (err) res.send(err);
                res.send(token);
              }
            );
          } else {
            res.end("Login Failed")
          }
        }
      }
    )
    .catch((err) => {
      res.send(err);
    })
};
//
exports.pughome=function(req, res){
  //res.send('You are on the pug home route.');
  res.render('layout');
};
